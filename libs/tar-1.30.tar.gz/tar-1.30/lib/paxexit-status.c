#include <system.h>
#include <paxlib.h>
int exit_status = PAXEXIT_SUCCESS;
