.. cmake-module:: ../../Modules/CheckCXXCompilerFlag.cmake
