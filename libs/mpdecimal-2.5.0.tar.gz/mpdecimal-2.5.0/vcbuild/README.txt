

libmpdec and libmpdec++ build instructions for Visual Studio
============================================================

   64-bit build
   ------------

      Run vcbuild64.bat. If successful, the static library, the dynamic
      library and the common header file should be in the dist64 directory.


   32-bit build
   ------------

      Run vcbuild32.bat. If successful, the static library, the dynamic
      library and the common header file should be in the dist32 directory.


   Run the unit tests
   ------------------

      Execute runshort.bat. This attempts to download the official IBM
      test cases (text files).



